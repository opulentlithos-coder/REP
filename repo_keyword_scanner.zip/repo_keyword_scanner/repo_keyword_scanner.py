#!/usr/bin/env python3
"""
Multi-provider repo keyword scanner -> Excel report.

Works with Bitbucket Server/DC, Bitbucket Cloud, GitHub (incl. Enterprise) and
GitLab (gitlab.com or self-hosted). Scans every repo under the given
project / org / group (or only the repos you name) for a keyword inside selected
file types (default: pom.xml, *.pom, *.json, *.gradle) and writes a formatted
Excel workbook.

Required:
  --url    project / org / group / repo URL, e.g.
             https://bitbucket.operative.com/projects/ONO                (Bitbucket Server)
             https://bitbucket.operative.com/projects/ONO/repos/postings/browse
             https://bitbucket.org/myworkspace                           (Bitbucket Cloud)
             https://github.com/my-org  or  https://github.com/my-org/my-repo
             https://gitlab.com/my-group/sub-group  or  .../my-group/my-repo
  --query  keyword (or regex with --regex)

Optional:
  --repo           repo name(s), comma separated, wildcards ok ("post*,billing")
  --ext            extensions / file names, comma separated (".json,.gradle,pom.xml")
  --branch         branch/tag (default: each repo's default branch)
  --regex, --case-sensitive, --exclude-path, --max-size-kb, --workers
  --provider       bitbucket-server | bitbucket-cloud | github | gitlab (auto-detected from URL)
  --api-url        override API base URL (rarely needed)
  --fast           Bitbucket Server only: use server-side code search (very fast, but word-based:
                   'mongo' will NOT match 'mongodb'; default branch only)
  --output         xlsx path (default: scan_<query>_<timestamp>.xlsx next to script)
  --token          access token (or env: BITBUCKET_TOKEN / GITHUB_TOKEN / GITLAB_TOKEN / SCAN_TOKEN)
  --user/--password  basic auth (env BITBUCKET_USER / BITBUCKET_PASSWORD) - Bitbucket only
  --no-verify-ssl

Example:
  set GITHUB_TOKEN=ghp_xxx
  python repo_keyword_scanner.py --url https://github.com/my-org --query log4j --ext .gradle,pom.xml
"""
import argparse
import fnmatch
import html
import os
import re
import sys
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
from urllib.parse import urlparse, quote

import requests
from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

DEFAULT_EXTS = ["pom.xml", ".pom", ".json", ".gradle"]
DEFAULT_EXCLUDES = ["node_modules/", "package-lock.json", "/target/", "/build/"]

NAVY, BLUE, LIGHT, ZEBRA, GREEN, GREY = "1F3864", "2F5597", "DDEBF7", "F2F7FC", "E2EFDA", "808080"
THIN = Side(style="thin", color="BFBFBF")
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)
print_lock = threading.Lock()

PROVIDER_LABEL = {"bitbucket-server": "Bitbucket Server", "bitbucket-cloud": "Bitbucket Cloud",
                  "github": "GitHub", "gitlab": "GitLab"}


def log(msg):
    with print_lock:
        print(msg, flush=True)


# ============================================================ providers
class Provider:
    """Common interface. repo dicts: {name, id, branch, size?}; files -> [(path, size|None)]."""
    name = ""
    token_env = ""

    def __init__(self, base, args):
        self.base = base.rstrip("/")
        self.s = requests.Session()
        self.s.verify = not args.no_verify_ssl
        if args.no_verify_ssl:
            requests.packages.urllib3.disable_warnings()
        self.auth(args)

    def auth(self, args):
        if args.token:
            self.s.headers["Authorization"] = f"Bearer {args.token}"
        elif args.user and args.password:
            self.s.auth = (args.user, args.password)

    def get(self, url, **kw):
        """GET with retry on rate-limit / transient errors."""
        for attempt in range(5):
            r = self.s.get(url, timeout=90, **kw)
            limited = r.status_code == 429 or (r.status_code == 403 and r.headers.get("X-RateLimit-Remaining") == "0")
            if limited and not self.s.headers.get("Authorization") and not self.s.headers.get("PRIVATE-TOKEN") \
                    and not self.s.auth:
                sys.exit("Rate limit hit without a token - pass --token (or the provider's env var, "
                         "e.g. GITHUB_TOKEN) to get a much higher limit.")
            if limited or r.status_code in (502, 503, 504):
                wait = int(r.headers.get("Retry-After", 0)) or 2 ** (attempt + 1)
                reset = r.headers.get("X-RateLimit-Reset")
                if limited and reset and reset.isdigit():
                    wait = max(wait, min(int(reset) - int(time.time()) + 1, 120))
                log(f"  .. rate-limited/transient ({r.status_code}), waiting {wait}s")
                time.sleep(wait)
                continue
            if r.status_code == 401:
                sys.exit("401 Unauthorized - give a valid --token (or the provider's env var) with read access.")
            return r
        r.raise_for_status()
        return r

    def repos(self, owner, only_repo):  # pragma: no cover
        raise NotImplementedError

    def files(self, repo, branch):  # pragma: no cover
        raise NotImplementedError

    def raw(self, repo, path, branch):  # pragma: no cover
        raise NotImplementedError

    def link(self, repo, path, line, branch):  # pragma: no cover
        raise NotImplementedError


class BitbucketServer(Provider):
    name, token_env = "bitbucket-server", "BITBUCKET_TOKEN"

    def _api(self, path, **params):
        r = self.get(f"{self.base}/rest/api/1.0{path}", params=params)
        r.raise_for_status()
        return r

    def _paged(self, path, **params):
        start = 0
        while True:
            data = self._api(path, start=start, limit=1000, **params).json()
            yield from data.get("values", [])
            if data.get("isLastPage", True):
                return
            start = data["nextPageStart"]

    def repos(self, owner, only_repo):
        return [{"name": r["name"], "id": r["slug"], "branch": None, "owner": owner}
                for r in self._paged(f"/projects/{quote(owner)}/repos")]

    def files(self, repo, branch):
        extra = {"at": branch} if branch else {}
        return [(p, None) for p in self._paged(f"/projects/{quote(repo['owner'])}/repos/{quote(repo['id'])}/files", **extra)]

    def raw(self, repo, path, branch):
        extra = {"at": branch} if branch else {}
        r = self._api(f"/projects/{quote(repo['owner'])}/repos/{quote(repo['id'])}/raw/{quote(path)}", **extra)
        return r.content

    def link(self, repo, path, line, branch):
        at = f"?at={quote(branch)}" if branch else ""
        return f"{self.base}/projects/{quote(repo['owner'])}/repos/{quote(repo['id'])}/browse/{quote(path)}{at}#{line}"

    # ---- optional fast mode: server-side code search (word based, default branch only)
    def search(self, query, limit=100):
        start = 0
        while True:
            body = {"query": query, "entities": {"code": {}}, "limits": {"primary": limit, "secondary": 0}}
            r = self.s.post(f"{self.base}/rest/search/latest/search", json=body, params={"start": start}, timeout=120)
            if r.status_code == 401:
                sys.exit("401 Unauthorized - give a valid --token.")
            r.raise_for_status()
            code = r.json().get("code", {})
            yield from code.get("values", [])
            if code.get("isLastPage", True):
                return
            start = code["nextStart"]


class BitbucketCloud(Provider):
    name, token_env = "bitbucket-cloud", "BITBUCKET_TOKEN"

    def _paged(self, url, **params):
        while url:
            r = self.get(url, params=params)
            r.raise_for_status()
            data = r.json()
            yield from data.get("values", [])
            url, params = data.get("next"), {}

    def repos(self, owner, only_repo):
        url = f"{self.base}/repositories/{quote(owner)}"
        return [{"name": r["name"], "id": r["slug"], "owner": owner,
                 "branch": (r.get("mainbranch") or {}).get("name") or "HEAD"}
                for r in self._paged(url, pagelen=100)]

    def files(self, repo, branch):
        ref = quote(branch or repo["branch"], safe="")
        url = f"{self.base}/repositories/{quote(repo['owner'])}/{quote(repo['id'])}/src/{ref}/"
        return [(v["path"], v.get("size")) for v in self._paged(url, max_depth=50, pagelen=100)
                if v.get("type") == "commit_file"]

    def raw(self, repo, path, branch):
        ref = quote(branch or repo["branch"], safe="")
        r = self.get(f"{self.base}/repositories/{quote(repo['owner'])}/{quote(repo['id'])}/src/{ref}/{quote(path)}")
        r.raise_for_status()
        return r.content

    def link(self, repo, path, line, branch):
        ref = quote(branch or repo["branch"], safe="")
        return f"https://bitbucket.org/{quote(repo['owner'])}/{quote(repo['id'])}/src/{ref}/{quote(path)}#lines-{line}"


class GitHub(Provider):
    name, token_env = "github", "GITHUB_TOKEN"

    def auth(self, args):
        self.s.headers["Accept"] = "application/vnd.github+json"
        if args.token:
            self.s.headers["Authorization"] = f"Bearer {args.token}"

    def _list(self, url):
        page = 1
        while True:
            r = self.get(url, params={"per_page": 100, "page": page})
            if r.status_code == 404:
                return None
            r.raise_for_status()
            items = r.json()
            if not items:
                return
            yield from items
            if len(items) < 100:
                return
            page += 1

    def repos(self, owner, only_repo):
        if only_repo:
            r = self.get(f"{self.base}/repos/{owner}/{only_repo}")
            r.raise_for_status()
            items = [r.json()]
        else:
            items = None
            for kind in ("orgs", "users"):
                gen = self._list(f"{self.base}/{kind}/{owner}/repos")
                first = next(gen, "none")
                if first is None:  # 404 -> try the other kind
                    continue
                items = [] if first == "none" else [first, *gen]
                break
            if items is None:
                sys.exit(f"GitHub org/user '{owner}' not found (or token lacks access).")
        return [{"name": r["name"], "id": r["full_name"], "owner": owner, "branch": r.get("default_branch") or "HEAD",
                 "web": r["html_url"]} for r in items if not r.get("size") == 0]

    def files(self, repo, branch):
        ref = quote(branch or repo["branch"], safe="")
        r = self.get(f"{self.base}/repos/{repo['id']}/git/trees/{ref}", params={"recursive": 1})
        if r.status_code in (404, 409):  # missing branch / empty repo
            return []
        r.raise_for_status()
        data = r.json()
        if data.get("truncated"):
            log(f"  ! {repo['name']}: tree truncated by GitHub (very large repo) - some files not scanned")
        return [(t["path"], t.get("size")) for t in data.get("tree", []) if t["type"] == "blob"]

    def raw(self, repo, path, branch):
        r = self.get(f"{self.base}/repos/{repo['id']}/contents/{quote(path)}",
                     params={"ref": branch or repo["branch"]},
                     headers={"Accept": "application/vnd.github.raw+json"})
        r.raise_for_status()
        return r.content

    def link(self, repo, path, line, branch):
        return f"{repo['web']}/blob/{quote(branch or repo['branch'], safe='')}/{quote(path)}#L{line}"


class GitLab(Provider):
    name, token_env = "gitlab", "GITLAB_TOKEN"

    def auth(self, args):
        if args.token:
            self.s.headers["PRIVATE-TOKEN"] = args.token

    def _list(self, url, **params):
        page = 1
        while page:
            r = self.get(url, params={"per_page": 100, "page": page, **params})
            if r.status_code == 404:
                return None
            r.raise_for_status()
            yield from r.json()
            page = int(r.headers["X-Next-Page"]) if r.headers.get("X-Next-Page") else 0

    def repos(self, owner, only_repo):
        enc = quote(owner, safe="")
        if only_repo:
            r = self.get(f"{self.base}/projects/{quote(owner + '/' + only_repo, safe='')}")
            r.raise_for_status()
            items = [r.json()]
        else:
            gen = self._list(f"{self.base}/groups/{enc}/projects", include_subgroups="true", archived="false")
            first = next(gen, "none")
            if first is None:  # not a group -> maybe a single project URL
                r = self.get(f"{self.base}/projects/{enc}")
                if r.status_code == 404:
                    sys.exit(f"GitLab group/project '{owner}' not found (or token lacks access).")
                r.raise_for_status()
                items = [r.json()]
            else:
                items = [] if first == "none" else [first, *gen]
        return [{"name": r["path_with_namespace"], "id": r["id"], "owner": owner,
                 "branch": r.get("default_branch") or "HEAD", "web": r["web_url"]}
                for r in items if r.get("default_branch")]

    def files(self, repo, branch):
        gen = self._list(f"{self.base}/projects/{repo['id']}/repository/tree",
                         recursive="true", ref=branch or repo["branch"])
        return [(t["path"], None) for t in (gen or []) if t["type"] == "blob"]

    def raw(self, repo, path, branch):
        r = self.get(f"{self.base}/projects/{repo['id']}/repository/files/{quote(path, safe='')}/raw",
                     params={"ref": branch or repo["branch"]})
        r.raise_for_status()
        return r.content

    def link(self, repo, path, line, branch):
        return f"{repo['web']}/-/blob/{quote(branch or repo['branch'], safe='')}/{quote(path)}#L{line}"


PROVIDERS = {c.name: c for c in (BitbucketServer, BitbucketCloud, GitHub, GitLab)}


# ============================================================ URL parsing
def parse_url(url, forced=None, api_url=None):
    """Return (provider_name, api_base, owner, repo_or_None)."""
    p = urlparse(url.strip())
    if not p.scheme or not p.netloc:
        sys.exit(f"Invalid URL: {url}")
    host = p.netloc.lower()
    parts = [x for x in p.path.split("/") if x]
    low = [x.lower() for x in parts]
    root = f"{p.scheme}://{p.netloc}"

    prov = forced
    if not prov:
        if host in ("bitbucket.org", "www.bitbucket.org"):
            prov = "bitbucket-cloud"
        elif "projects" in low or "scm" in low or ("users" in low and "repos" in low):
            prov = "bitbucket-server"
        elif "gitlab" in host:
            prov = "gitlab"
        elif "github" in host:
            prov = "github"
        elif "bitbucket" in host:
            prov = "bitbucket-server"
        else:
            sys.exit("Cannot tell the provider from the URL - pass --provider "
                     "(bitbucket-server | bitbucket-cloud | github | gitlab).")

    if prov == "bitbucket-server":
        for marker in ("projects", "scm", "users"):
            if marker in low and len(parts) > low.index(marker) + 1:
                i = low.index(marker)
                base = root + "".join("/" + x for x in parts[:i])
                key = parts[i + 1]
                key = "~" + key if marker == "users" else (key.upper() if marker == "scm" else key)
                repo = None
                if marker == "scm" and len(parts) > i + 2:
                    repo = re.sub(r"\.git$", "", parts[i + 2])
                elif "repos" in low[i:] and len(parts) > low.index("repos", i) + 1:
                    repo = parts[low.index("repos", i) + 1]
                return prov, api_url or base, key, repo
        sys.exit("Bitbucket Server URL should look like .../projects/KEY[/repos/NAME] or .../scm/key/repo.git")

    if not parts:
        sys.exit("URL has no org/workspace/group in it.")
    parts[-1] = re.sub(r"\.git$", "", parts[-1])

    if prov == "bitbucket-cloud":
        return prov, api_url or "https://api.bitbucket.org/2.0", parts[0], parts[1] if len(parts) > 1 else None

    if prov == "github":
        api = api_url or ("https://api.github.com" if host in ("github.com", "www.github.com") else f"{root}/api/v3")
        return prov, api, parts[0], parts[1] if len(parts) > 1 else None

    # gitlab: group may have sub-groups, so URL path is either a group or group/.../repo (resolved via API)
    parts = parts[: low.index("-")] if "-" in low else parts
    return prov, api_url or f"{root}/api/v4", "/".join(parts), None


# ============================================================ scan logic
def ext_matcher(exts):
    exts = [e.strip().lower() for e in exts if e.strip()]
    return lambda path: any(path.lower().endswith(e) for e in exts)


def scan_repo(prov, repo, args, matches_ext, line_match):
    result = {"repo": repo["name"], "repo_ref": repo, "files_checked": 0, "hits": [], "error": None}
    try:
        paths = [(p, sz) for p, sz in prov.files(repo, args.branch)
                 if matches_ext(p) and not any(x in "/" + p for x in args.excludes)]
        limit = args.max_size_kb * 1024

        def one(item):
            path, size = item
            if size is not None and size > limit:
                return path, None
            try:
                return path, prov.raw(repo, path, args.branch)
            except requests.RequestException as e:
                log(f"  ! {repo['name']}: cannot read {path}: {e}")
                return path, None

        with ThreadPoolExecutor(max_workers=args.file_workers) as pool:
            for path, raw in pool.map(one, paths):
                if raw is None or len(raw) > limit:
                    continue
                result["files_checked"] += 1
                for n, line in enumerate(raw.decode("utf-8", errors="replace").splitlines(), 1):
                    m = line_match(line)
                    if m:
                        result["hits"].append((path, n, line.strip()[:500], m))
    except requests.RequestException as e:
        result["error"] = str(e)
    return result


EM_TAG = re.compile(r"</?em>")


def fast_search_scan(prov, owner, repos, exts, args, matches_ext, line_match):
    """Bitbucket Server only: server-side code search. Word based -> may miss substrings."""
    by_slug = {r["id"]: {"repo": r["name"], "repo_ref": r, "files_checked": None, "hits": [],
                         "error": None, "_seen": set()} for r in repos}
    scopes = [f"project:{owner}"]
    if args.repo or len(repos) == 1:
        scopes = [f"project:{owner} repo:{r['id']}" for r in repos]
    search_exts = sorted({e.rsplit(".", 1)[-1].lower() for e in exts})
    q = args.query if " " not in args.query else f'"{args.query}"'
    for scope in scopes:
        for ext in search_exts:
            for res in prov.search(f"{q} {scope} ext:{ext}"):
                slug, path = res["repository"]["slug"], res["file"]
                if slug not in by_slug or not matches_ext(path) or any(x in "/" + path for x in args.excludes):
                    continue
                out = by_slug[slug]
                for ctx in res.get("hitContexts", []):
                    for ln in ctx:
                        if "<em>" not in ln["text"]:
                            continue
                        text = html.unescape(EM_TAG.sub("", ln["text"])).strip()
                        m = line_match(text)
                        if m and (path, ln["line"]) not in out["_seen"]:
                            out["_seen"].add((path, ln["line"]))
                            out["hits"].append((path, ln["line"], text[:500], m))
    return list(by_slug.values())


# ============================================================ excel
def style_header(ws, ncols):
    for c in range(1, ncols + 1):
        cell = ws.cell(row=1, column=c)
        cell.font = Font(bold=True, color="FFFFFF", name="Calibri", size=11)
        cell.fill = PatternFill("solid", fgColor=BLUE)
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        cell.border = BORDER
    ws.row_dimensions[1].height = 26


def write_table(ws, headers, rows, widths, link_col=None):
    ws.append(headers)
    style_header(ws, len(headers))
    for r, row in enumerate(rows, 2):
        ws.append(row)
        fill = PatternFill("solid", fgColor=ZEBRA) if r % 2 else None
        for c in range(1, len(headers) + 1):
            cell = ws.cell(row=r, column=c)
            cell.border = BORDER
            cell.alignment = Alignment(vertical="top", wrap_text=True)
            if fill:
                cell.fill = fill
        if link_col:
            cell = ws.cell(row=r, column=link_col)
            cell.hyperlink = cell.value
            cell.value = "Open"
            cell.font = Font(color="0563C1", underline="single")
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = f"A1:{get_column_letter(len(headers))}{max(len(rows) + 1, 2)}"
    for i, w in enumerate(widths, 1):
        ws.column_dimensions[get_column_letter(i)].width = w


def build_excel(path, meta, results, link_for):
    wb = Workbook()

    ws = wb.active
    ws.title = "Summary"
    ws.sheet_view.showGridLines = False
    ws.merge_cells("B2:C2")
    ws["B2"] = "Repository Keyword Scan"
    ws["B2"].font = Font(size=20, bold=True, color="FFFFFF")
    ws["B2"].fill = PatternFill("solid", fgColor=NAVY)
    ws["B2"].alignment = Alignment(vertical="center", indent=1)
    ws.row_dimensions[2].height = 38
    total_hits = sum(len(r["hits"]) for r in results)
    repos_hit = sum(1 for r in results if r["hits"])
    files_hit = sum(len({h[0] for h in r["hits"]}) for r in results)
    info = [
        ("Query", meta["query"]), ("Mode", meta["mode"]),
        ("Provider", meta["provider"]), ("Project / Org", meta["owner"]),
        ("Source URL", meta["url"]), ("File types", ", ".join(meta["exts"])),
        ("Branch", meta["branch"] or "default branch of each repo"),
        ("Scan method", "download + exact local match" if meta["download"] else "Bitbucket server-side code search (word based)"),
        ("Scanned on", datetime.now().strftime("%d %b %Y, %H:%M")),
        (None, None),
        ("Repos scanned", len(results)), ("Repos with matches", repos_hit),
        ("Files with matches", files_hit), ("Total matching lines", total_hits),
        ("Files checked", sum(r["files_checked"] or 0 for r in results) if meta["download"] else "n/a"),
        ("Repos with errors", sum(1 for r in results if r["error"])),
    ]
    for i, (k, v) in enumerate(info, 4):
        if k is None:
            continue
        a, b = ws.cell(row=i, column=2, value=k), ws.cell(row=i, column=3, value=v)
        a.font = Font(bold=True, color=NAVY)
        a.fill = PatternFill("solid", fgColor=LIGHT)
        a.border = b.border = BORDER
        b.alignment = Alignment(horizontal="left", wrap_text=True)
        if k in ("Repos with matches", "Total matching lines") and v:
            b.fill = PatternFill("solid", fgColor=GREEN)
            b.font = Font(bold=True)
    for col, w in (("A", 3), ("B", 26), ("C", 70)):
        ws.column_dimensions[col].width = w

    rows = []
    for r in sorted(results, key=lambda x: x["repo"].lower()):
        for path_, line_no, text, hit in r["hits"]:
            rows.append([r["repo"], path_, line_no, text, hit, link_for(r["repo_ref"], path_, line_no)])
    ws = wb.create_sheet("Matches")
    write_table(ws, ["Repository", "File Path", "Line", "Line Content", "Matched Text", "Link"],
                rows, [28, 55, 8, 80, 22, 10], link_col=6)
    for r in range(2, len(rows) + 2):
        ws.cell(row=r, column=5).font = Font(bold=True, color="C00000")
        ws.cell(row=r, column=3).alignment = Alignment(horizontal="center", vertical="top")

    ws = wb.create_sheet("By Repository")
    rrows = []
    for r in sorted(results, key=lambda x: (-len(x["hits"]), x["repo"].lower())):
        status = "ERROR: " + r["error"] if r["error"] else ("FOUND" if r["hits"] else "Not found")
        rrows.append([r["repo"], r["files_checked"] if r["files_checked"] is not None else "n/a",
                      len({h[0] for h in r["hits"]}), len(r["hits"]), status])
    write_table(ws, ["Repository", "Files Checked", "Files With Match", "Matching Lines", "Status"],
                rrows, [38, 15, 17, 16, 60])
    for r in range(2, len(rrows) + 2):
        st = ws.cell(row=r, column=5)
        if st.value == "FOUND":
            st.fill = PatternFill("solid", fgColor=GREEN)
            st.font = Font(bold=True, color="375623")
        elif str(st.value).startswith("ERROR"):
            st.font = Font(bold=True, color="C00000")
        else:
            st.font = Font(color=GREY)
        for c in (2, 3, 4):
            ws.cell(row=r, column=c).alignment = Alignment(horizontal="center", vertical="top")

    wb.save(path)


# ============================================================ main
def main():
    ap = argparse.ArgumentParser(description="Scan repos (Bitbucket/GitHub/GitLab) for a keyword and export to Excel.")
    ap.add_argument("--url", required=True, help="project / org / group / repo URL")
    ap.add_argument("--query", required=True, help="keyword (or regex with --regex)")
    ap.add_argument("--repo", help="repo name(s), comma separated, wildcards allowed")
    ap.add_argument("--ext", help=f"file extensions/names, comma separated (default: {','.join(DEFAULT_EXTS)})")
    ap.add_argument("--branch", help="branch/tag (default: repo default branch)")
    ap.add_argument("--provider", choices=sorted(PROVIDERS), help="auto-detected from URL if omitted")
    ap.add_argument("--api-url", help="override API base URL")
    ap.add_argument("--fast", action="store_true",
                    help="Bitbucket Server only: server-side search (fast but word-based, may miss substrings)")
    ap.add_argument("--regex", action="store_true", help="treat query as regular expression")
    ap.add_argument("--case-sensitive", action="store_true")
    ap.add_argument("--exclude-path", help="extra path fragments to skip, comma separated")
    ap.add_argument("--max-size-kb", type=int, default=2048, help="skip files bigger than this (default 2048)")
    ap.add_argument("--workers", type=int, default=6, help="repos scanned in parallel")
    ap.add_argument("--file-workers", type=int, default=8, help="files fetched in parallel per repo")
    ap.add_argument("--output", help="output .xlsx path")
    ap.add_argument("--token")
    ap.add_argument("--user", default=os.getenv("BITBUCKET_USER"))
    ap.add_argument("--password", default=os.getenv("BITBUCKET_PASSWORD"))
    ap.add_argument("--no-verify-ssl", action="store_true")
    args = ap.parse_args()

    prov_name, api_base, owner, url_repo = parse_url(args.url, args.provider, args.api_url)
    cls = PROVIDERS[prov_name]
    args.token = args.token or os.getenv(cls.token_env) or os.getenv("SCAN_TOKEN")

    exts = [e.strip() for e in args.ext.split(",") if e.strip()] if args.ext else DEFAULT_EXTS
    exts = [e if "." in e else "." + e for e in exts]
    args.excludes = DEFAULT_EXCLUDES + ([e.strip() for e in args.exclude_path.split(",")] if args.exclude_path else [])

    pattern = re.compile(args.query if args.regex else re.escape(args.query),
                         0 if args.case_sensitive else re.IGNORECASE)

    def line_match(line):
        m = pattern.search(line)
        return m.group(0) if m else None

    prov = cls(api_base, args)
    print(f"{PROVIDER_LABEL[prov_name]}: {api_base} | {owner}")
    repos = prov.repos(owner, url_repo)

    wanted = [x.strip().lower() for x in args.repo.split(",")] if args.repo else []
    if wanted:
        repos = [r for r in repos if any(fnmatch.fnmatch(r["name"].lower(), w) or
                                         fnmatch.fnmatch(str(r["id"]).lower(), w) for w in wanted)]
    elif url_repo and prov_name == "bitbucket-server":
        repos = [r for r in repos if r["id"].lower() == url_repo.lower()]
    if not repos:
        sys.exit("No repositories matched.")
    print(f"Scanning {len(repos)} repo(s) for '{args.query}' in {', '.join(exts)} ...")

    matches_ext = ext_matcher(exts)
    if args.fast and prov_name != "bitbucket-server":
        sys.exit("--fast is only available for Bitbucket Server.")
    download = not (args.fast and not args.regex and not args.branch)
    if args.fast and not download:
        print("Note: --regex/--branch need file contents, falling back to download scan.")

    if download:
        print("Mode: download + exact match")
        results = []
        with ThreadPoolExecutor(max_workers=args.workers) as pool:
            futs = [pool.submit(scan_repo, prov, r, args, matches_ext, line_match) for r in repos]
            for i, f in enumerate(as_completed(futs), 1):
                res = f.result()
                tag = f"{len(res['hits'])} hit(s)" if res["hits"] else ("ERROR" if res["error"] else "-")
                log(f"[{i}/{len(repos)}] {res['repo']}: {res['files_checked']} files, {tag}")
                results.append(res)
    else:
        print("Mode: Bitbucket server-side search (fast; word based, default branch only)")
        results = fast_search_scan(prov, owner, repos, exts, args, matches_ext, line_match)
        for res in results:
            if res["hits"]:
                log(f"  {res['repo']}: {len(res['hits'])} hit(s)")

    safe_q = re.sub(r"[^A-Za-z0-9_.-]+", "_", args.query)[:40]
    out = args.output or os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                      f"scan_{safe_q}_{datetime.now():%Y%m%d_%H%M%S}.xlsx")
    meta = {"query": args.query,
            "mode": ("regex" if args.regex else "keyword") +
                    (", case-sensitive" if args.case_sensitive else ", case-insensitive"),
            "provider": PROVIDER_LABEL[prov_name], "owner": owner, "url": args.url, "exts": exts,
            "branch": args.branch, "download": download}
    build_excel(out, meta, results, lambda repo, path, line: prov.link(repo, path, line, args.branch))
    print(f"\nDone. {sum(len(r['hits']) for r in results)} matching line(s) in "
          f"{sum(1 for r in results if r['hits'])} repo(s).\nExcel: {out}")


if __name__ == "__main__":
    try:
        main()
    except requests.exceptions.SSLError as e:
        sys.exit(f"SSL certificate error (corporate proxy / self-signed cert?): re-run with --no-verify-ssl\n{e}")
    except requests.exceptions.RequestException as e:
        sys.exit(f"Request failed: {e}")
