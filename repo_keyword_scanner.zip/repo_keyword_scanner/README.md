# Repo Keyword Scanner

Scans many repositories for a keyword inside selected file types and writes a formatted Excel report.

Supported providers (auto-detected from the URL): **Bitbucket Server/DC**, **Bitbucket Cloud**, **GitHub** (incl. Enterprise), **GitLab** (gitlab.com or self-hosted).

## Setup

```
pip install requests openpyxl
```

Create an access token with **read** access and expose it as an environment variable:

| Provider | Environment variable | Token type |
|---|---|---|
| Bitbucket Server/DC | `BITBUCKET_TOKEN` | HTTP access token |
| Bitbucket Cloud | `BITBUCKET_TOKEN` | Repository/workspace access token (or `BITBUCKET_USER` + `BITBUCKET_PASSWORD` app password) |
| GitHub | `GITHUB_TOKEN` | Personal access token (fine-grained or classic) |
| GitLab | `GITLAB_TOKEN` | Personal/group access token (`read_api` + `read_repository`) |
| Any | `SCAN_TOKEN` | Fallback if the one above is not set |

```
Windows (cmd):    set GITHUB_TOKEN=xxxx
PowerShell:       $env:GITHUB_TOKEN = "xxxx"
Linux/macOS:      export GITHUB_TOKEN=xxxx
```

You can also pass `--token xxxx` directly. Never commit tokens to git.

## Arguments

Only `--url` and `--query` are required.

| Argument | Required | Accepts multiple? | Description |
|---|---|---|---|
| `--url` | **Yes** | No (one URL per run) | Project / org / workspace / group URL, or a single repo URL |
| `--query` | **Yes** | No (one keyword per run) | Text to search for (plain text by default) |
| `--repo` | No | **Yes**, comma separated | Repo name(s) to scan. Wildcards allowed (`post*`). Default: all repos under the URL |
| `--ext` | No | **Yes**, comma separated | File extensions or file names. Default: `pom.xml,.pom,.json,.gradle` |
| `--branch` | No | No | Branch or tag. Default: each repo's default branch |
| `--regex` | No | - | Treat `--query` as a regular expression |
| `--case-sensitive` | No | - | Default is case-insensitive |
| `--exclude-path` | No | **Yes**, comma separated | Path fragments to skip (added to defaults: `node_modules/`, `package-lock.json`, `/target/`, `/build/`) |
| `--max-size-kb` | No | No | Skip files bigger than this. Default `2048` |
| `--workers` | No | No | Repos scanned in parallel. Default `6` |
| `--file-workers` | No | No | Files fetched in parallel per repo. Default `8` |
| `--output` | No | No | Excel path. Default: `scan_<query>_<timestamp>.xlsx` next to the script |
| `--provider` | No | No | `bitbucket-server`, `bitbucket-cloud`, `github`, `gitlab`. Needed only for custom domains |
| `--api-url` | No | No | Override the API base URL (rarely needed) |
| `--fast` | No | - | Bitbucket Server only: server-side search, much faster but word-based (see notes) |
| `--token` | No | No | Access token (instead of the environment variable) |
| `--user` / `--password` | No | No | Basic auth (Bitbucket only) |
| `--no-verify-ssl` | No | - | Skip SSL certificate check (only if your proxy breaks it) |

## URL formats

| Provider | Scan everything | Scan one repo |
|---|---|---|
| Bitbucket Server | `https://bitbucket.company.com/projects/ONO` | `https://bitbucket.company.com/projects/ONO/repos/postings/browse` or `.../scm/ono/postings.git` |
| Bitbucket Cloud | `https://bitbucket.org/my-workspace` | `https://bitbucket.org/my-workspace/my-repo` |
| GitHub | `https://github.com/my-org` | `https://github.com/my-org/my-repo` |
| GitLab | `https://gitlab.com/my-group` (sub-groups included) | `--repo my-repo` with the group URL |

## Examples

**Minimum (only the 2 required arguments)** - all repos, default file types:
```
python repo_keyword_scanner.py --url https://github.com/my-org --query log4j
```

**One repo** (by `--repo`):
```
python repo_keyword_scanner.py --url https://github.com/my-org --query log4j --repo billing-service
```

**Multiple repos:**
```
python repo_keyword_scanner.py --url https://github.com/my-org --query log4j --repo "billing-service,postings,mdm-backend"
```

**Repos by wildcard:**
```
python repo_keyword_scanner.py --url https://github.com/my-org --query log4j --repo "post*,*-backend"
```

**One file extension:**
```
python repo_keyword_scanner.py --url https://github.com/my-org --query log4j --ext .gradle
```

**Multiple file extensions / file names:**
```
python repo_keyword_scanner.py --url https://github.com/my-org --query log4j --ext ".gradle,pom.xml,.json,.yml"
```

**Multiple repos + multiple extensions together:**
```
python repo_keyword_scanner.py --url https://bitbucket.company.com/projects/ONO --query mongo --repo "postings,RateCard" --ext ".gradle,pom.xml"
```

**Single repo URL (no `--repo` needed):**
```
python repo_keyword_scanner.py --url https://bitbucket.company.com/projects/ONO/repos/postings/browse --query mongo
```

**Specific branch:**
```
python repo_keyword_scanner.py --url https://github.com/my-org --query log4j --branch release/2.0
```

**Regular expression (e.g. any log4j 1.x/2.x version):**
```
python repo_keyword_scanner.py --url https://github.com/my-org --query "log4j.*2\.1[0-5]\." --regex
```

**Case-sensitive search:**
```
python repo_keyword_scanner.py --url https://github.com/my-org --query LOG4J --case-sensitive
```

**Skip folders (multiple):**
```
python repo_keyword_scanner.py --url https://github.com/my-org --query log4j --exclude-path "test/,docs/,examples/"
```

**Custom output file:**
```
python repo_keyword_scanner.py --url https://github.com/my-org --query log4j --output C:\reports\log4j_scan.xlsx
```

**GitLab (group with sub-groups, then a single repo from it):**
```
python repo_keyword_scanner.py --url https://gitlab.com/my-group --query log4j
python repo_keyword_scanner.py --url https://gitlab.com/my-group --query log4j --repo "svc-a,svc-b"
```

**Bitbucket Cloud:**
```
python repo_keyword_scanner.py --url https://bitbucket.org/my-workspace --query log4j --repo my-repo
```

**Self-hosted / custom domain (provider cannot be guessed from the URL):**
```
python repo_keyword_scanner.py --url https://code.company.com/my-org --provider github --api-url https://code.company.com/api/v3 --query log4j
```

**Several keywords:** the script takes one keyword per run. Use a regex with `|`:
```
python repo_keyword_scanner.py --url https://github.com/my-org --query "log4j|mongo|jackson" --regex
```

**Fast check on Bitbucket Server** (seconds instead of minutes, but may miss partial words):
```
python repo_keyword_scanner.py --url https://bitbucket.company.com/projects/ONO --query mongo --fast
```

## Excel report

- **Summary** - query, provider, file types, branch, repos scanned, repos/files with matches, total matching lines.
- **Matches** - repository, file path, line number, line content, matched text and a clickable **Open** link to that exact line.
- **By Repository** - per-repo status (FOUND / Not found / ERROR), highest matches first.

All sheets have a styled header, filters and frozen header rows.

## Notes

- **Matching is exact substring** (`mongo` matches `mongodb`). `--fast` uses Bitbucket's own search, which is word-based, so it can miss such matches and only covers the default branch. `--regex` and `--branch` automatically fall back to the exact mode.
- `.pom` is matched as a file ending; `pom.xml` matches any file named like `*pom.xml`.
- Files larger than `--max-size-kb` are skipped. `--workers` / `--file-workers` can be lowered if you hit rate limits.
- GitHub without a token is limited to 60 API calls/hour; always use a token.
- If you get an SSL certificate error behind a corporate proxy, fix your certificate store or use `--no-verify-ssl`.
- Archived GitLab projects and empty repos are skipped.
